public class Task1 {
    public static void main(String[] args) {
        System.out.println("Иванов Валерий Петрович");
        System.out.println("50 лет");
        System.out.println("рост 175 см");
        System.out.println();
        System.out.println("Шахова Ирина Васильевна");
        System.out.println("25 лет");
        System.out.println("рост 162 см");
        System.out.println();
        System.out.println("Торгашова Елена Сергеевна");
        System.out.println("39 лет");
        System.out.println("рост 158 см");
        }
}